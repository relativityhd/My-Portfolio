class Player:
	def __init__(self):
		self.Name = ''
		self.Punkte = 0
		self.Auswahl = ''
	def s_N(self,wert):
		self.Name = wert
	def g_N(self):
		return self.Name
	def s_P(self,wertII):
		self.Punkte = wertII
	def g_P(self):
		return self.Punkte
	def s_A(self,wertIII):
		self.Auswahl = wertIII
	def g_A(self):
		return self.Auswahl
	def l_N(self):
		return len(self.Name)