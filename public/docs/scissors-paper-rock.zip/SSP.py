from PlayerKlasse import*
from random import randint
import random
import pickle as p
import os

def clear():
	if os.name == 'nt':    
		c = os.system('cls')
	else:
		c = os.system('clear')
	del c
clear()
print('Spielmodi: \n 1 for 1 vs. 1 \n 2 for 1 vs. PC \n 3 for PC vs. PC')
SM = raw_input('Spielmodi Eingabe: ')
SMListe = ['1', '2', '3']
while not SM in SMListe:
	SM = raw_input('Falsche Eingabe! Spielmodi Eingabe:')
Game = int(input('Wie viele Spiele willst du spielen?'))
while not Game > 0:
	Game = int(input('Falsche Eingabe! Muss mindestens 1 Spiel sein! Wie viele Spiele willst du spielen?'))
PCNamensliste = ['Kopernikus', 'Einstein', 'Newton', 'Buddah', 'Curie', 'Nelson', 'Edisson', 'Oppenheimer', 'Avenger', 'Hubble', 'Picard', 'Galileo']
Gameround = Game
liste = ['Schere', 'Stein' ,'Papier', 'Echse', 'Spock']

def PCA():
	print(str(i2.g_N()) + '`s Auswahl:' + str(i2.g_A()))
def U():
	print('Unentschieden!')
def G1():
	print(str(i1.g_N()) + ' gewinnt!')
def G2():
	print(str(i2.g_N()) + ' gewinnt!')
def S1():
	print(str(i1.g_N()) + '`s Auswahl: Schere')
def S2():
	print(str(i2.g_N()) + '`s Auswahl: Schere')
def P1():
	print(str(i1.g_N()) + '`s Auswahl: Papier')
def P2():
	print(str(i2.g_N()) + '`s Auswahl: Papier')
def R1():
	print(str(i1.g_N()) + '`s Auswahl: Stein')
def R2():
	print(str(i2.g_N()) + '`s Auswahl: Stein')
def L1():
	print(str(i1.g_N()) + '`s Auswahl: Echse')
def L2():
	print(str(i2.g_N()) + '`s Auswahl: Echse')
def Sp1():
	print(str(i1.g_N()) + '`s Auswahl: Spock')
def Sp2():
	print(str(i2.g_N()) + '`s Auswahl: Spock')

#nicht meins
def max_dict(dictionary):
	keys = list(dictionary.keys())
	for i in range(0, len(keys)):
		max = i
		for k in dictionary:
			if not k in keys[0:i] and dictionary[k] >= dictionary[keys[max]]:
				max = keys.index(k)
		ph = keys[i]
		keys[i] = keys[max]
		keys[max] = ph
	print('1. ' + keys[0] + ' : ' + str(dictionary[keys[0]]))
	print('2. ' + keys[1] + ' : ' + str(dictionary[keys[1]]))
	print('3. ' + keys[2] + ' : ' + str(dictionary[keys[2]]))

#ab hier meins
def n1Name():
	n1 = raw_input('Player 1:')
	i1.s_N(n1)
	i1n = 2
	i1l = i1.l_N()

	while i1l < i1n:
		print('Name zu kurz!')
		n1 = raw_input('Player 1:')
		i1.s_N(n1)
		i1l = i1.l_N()
		if not i1l < i1n:
			break
	print('Nick okay!')
def n2Name():
	n1 = i1.g_N()
	n2 = raw_input('Player 2:')
	i2.s_N(n2)
	i2n = 2
	i2l = i2.l_N()

	while i2l < i2n or n1 == n2:
		print('Name zu kurz oder gleich wie Player 1!')
		n2 = raw_input('Player 2:')
		i2.s_N(n2)
		i2l = i2.l_N()
	print('Nick okay!')

	clear()
def a1Auswahl():
	a1 = raw_input(str(i1.g_N()) + '; Schere, Stein, Papier, Echse oder Spock?')
	while not a1 in liste:
		a1 = raw_input('Falsche Eingabe!' + str(i1.g_N()) + '; Schere, Stein, Papier, Echse oder Spock?')
	clear()
	i1.s_A(a1)
def a2Auswahl():
	a2 = raw_input(str(i2.g_N()) + '; Schere, Stein, Papier, Echse oder Spock?')
	while not a2 in liste:
		a2 = raw_input('Falsche Eingabe!' + str(i2.g_N()) + '; Schere, Stein, Papier, Echse oder Spock?')
	clear()
	i2.s_A(a2)
def ImSpiel():
	print('Punktestand:')
	print(str(i1.g_N()) + ' : ' + str(i1.g_P()))
	print(str(i2.g_N()) + ' : ' + str(i2.g_P()))
	print
def EndSpiel():
	clear()
	print('Punktestand:')
	print(str(i1.g_N()) + ' : ' + str(i1.g_P()))
	print(str(i2.g_N()) + ' : ' + str(i2.g_P()))
	pe1 = i1.g_P()
	pe2 = i2.g_P()
	if pe1 > pe2:
		print(str(i1.g_N()) + ' hat gewonnen!')
	if pe1 < pe2:
		print(str(i2.g_N()) + ' hat gewonnen!')
	if pe1 == pe2:
		U()
def Spielen():
	p1 = i1.g_P()
	p2 = i2.g_P()
	a1 = i1.g_A()
	a2 = i2.g_A()
	if a1 == 'Schere':
		if a2 == 'Schere':
			U()
			S1()
			S2()
		if a2 == 'Stein':
			G2()
			S1()
			R2()
			p2 += 1
		if a2 == 'Spock':
			G2()
			S1()
			Sp2()
			p2 += 1
		if a2 == 'Papier':
			G1()
			S1()
			P2()
			p1 += 1
		if a2 == 'Echse':
			G1()
			S1()
			L2()
			p1 += 1
	if a1 == 'Papier':
		if a2 == 'Papier':
			U()
			P1()
			P2()
		if a2 == 'Schere':
			G2()
			P1()
			S2()
			p2 += 1
		if a2 == 'Echse':
			G2()
			P1()
			L2()
			p2 += 1
		if a2 == 'Stein':
			G1()
			P1()
			R2()
			p1 += 1
		if a2 == 'Spock':
			G1()
			P1()
			Sp2()
			p1 += 1
	if a1 == 'Stein':
		if a2 == 'Stein':
			U()
			R1()
			R2()
		if a2 == 'Papier':
			G2()
			R1()
			P2()
			p2 += 1
		if a2 == 'Spock':
			G2()
			R1()
			Sp2()
			p2 += 1
		if a2 == 'Schere':
			G1()
			R1()
			S2()
			p1 += 1
		if a2 == 'Echse':
			G1()
			R1()
			L2()
			p1 += 1
	if a1 == 'Spock':
		if a2 == 'Spock':
			U()
			Sp1()
			Sp2()
		if a2 == 'Papier':
			G2()
			Sp1()
			P2()
			p2 += 1
		if a2 == 'Echse':
			G2()
			Sp1()
			L2()
			p2 += 1
		if a2 == 'Schere':
			G1()
			Sp1()
			S2()
			p1 += 1	
		if a2 == 'Stein':
			G1()
			Sp1()
			R2()
			p1 += 1
	if a1 == 'Echse':
		if a2 == 'Echse':
			U()
			L1()
			L2()
		if a2 == 'Schere':
			G2()
			L1()
			S2()
			p2 += 1
		if a2 == 'Stein':
			G2()
			L1()
			S2()
			p2 += 1
		if a2 == 'Papier':
			G1()
			L1()
			P2()
			p1 += 1	
		if a2 == 'Spock':
			G1()
			L1()
			Sp2()
			p1 += 1
	i1.s_P(p1)
	i2.s_P(p2)
def PCLevelSchwer():
	a1Auswahl()
	a1 = i1.g_A()
	p1 = i1.g_P()
	p2 = i2.g_P()
	if a1 == 'Schere':
		listeSchere = ['Spock', 'Stein']
		a2 = random.choice(listeSchere)
		i2.s_A(a2)
		G2()
		S1()
		PCA()
		p2 += 1
	if a1 == 'Stein':
		listeStein = ['Spock', 'Papier']
		a2 = random.choice(listeStein)
		i2.s_A(a2)
		G2()
		R1()
		PCA()
		p2 += 1
	if a1 == 'Papier':
		listePapier = ['Echse', 'Schere']
		a2 = random.choice(listePapier)
		i2.s_A(a2)
		G2()
		P1()
		PCA()
		p2 += 1
	if a1 == 'Echse':
		listeEchse = ['Schere', 'Stein']
		a2 = random.choice(listeEchse)
		i2.s_A(a2)
		G2()
		L1()
		PCA()
		p2 += 1
	if a1 == 'Spock':
		listeSpock = ['Papier', 'Echse']
		a2 = random.choice(listeSpock)
		i2.s_A(a2)
		G2()
		Sp1()
		PCA()
		p2 += 1
	i1.s_P(p1)
	i2.s_P(p2)
def PCLevelEinfach():
	a1Auswahl()
	a1 = i1.g_A()
	p1 = i1.g_P()
	p2 = i2.g_P()
	if a1 == 'Schere':
		listeSchere = ['Papier', 'Echse']
		a2 = random.choice(listeSchere)
		i2.s_A(a2)
		G1()
		S1()
		PCA()
		p1 += 1
	if a1 == 'Stein':
		listeStein = ['Schere', 'Echse']
		a2 = random.choice(listeStein)
		i2.s_A(a2)
		G1()
		R1()
		PCA()
		p1 += 1
	if a1 == 'Papier':
		listePapier = ['Stein', 'Spock']
		a2 = random.choice(listePapier)
		i2.s_A(a2)
		G1()
		P1()
		PCA()
		p1 += 1
	if a1 == 'Echse':
		listeEchse = ['Spock', 'Papier']
		a2 = random.choice(listeEchse)
		i2.s_A(a2)
		G1()
		L1()
		PCA()
		p1 += 1
	if a1 == 'Spock':
		listeSpock = ['Schere', 'Stein']
		a2 = random.choice(listeSpock)
		i2.s_A(a2)
		G1()
		Sp1()
		PCA()
		p1 += 1
	i1.s_P(p1)
	i2.s_P(p2)

if SM == '1':
	i1 = Player()
	i2 = Player()
	n1Name()
	n2Name()
	i1.s_P(0)
	i2.s_P(0)
	
	while True:
		r = randint(1,2)
		if r == 1:
			print(str(i1.g_N()) + ' beginnt!')

			a1Auswahl()
			print(str(i2.g_N()) + ' ist jetzt dran!')
			a2Auswahl()
		if r == 2:
			print(str(i2.g_N()) + ' beginnt')
			a2Auswahl()
			print(str(i1.g_N()) + ' ist jetzt dran!')
			a1Auswahl()

		Spielen()

		Game -= 1
		p1 = i1.g_P()
		p2 = i2.g_P()
		if Game >= 1:
			ImSpiel()
		if Game == 0:
			EndSpiel()

			B1v1 = 'Bestenliste1v1.data'
			f = file(B1v1)
			d = p.load(f)
			f.close()

			schongespielt1 = False
			schongespielt2 = False
			for i in d:
				if i == i1.g_N():
					d[i] += i1.g_P()
					schongespielt1 = True
				elif i == i2.g_N():
					d[i] += i2.g_P()
					schongespielt2 =True
			if schongespielt1 == False:
				d [str(i1.g_N())] = int(i1.g_P())
			if schongespielt2 == False:
				d [str(i2.g_N())] = int(i2.g_P())
			f = file(B1v1, 'w')
			p.dump(d, f)
			f.close()

			Best = max_dict(d)
			break
if SM == '2':
	i1 = Player()			
	n1Name()
	n1 = i1.g_N()
	print('Level: \n 1 for Easy (Nur du gewinnst) \n 2 for Leicht \n 3 for Normal \n 4 for Schwer \n 5 for Godlike (Nur der PC gewinnt)')
	PCLevel = raw_input('Level Eingabe:')
	PCLevelListe = ['1', '2', '3', '4', '5']
	while not PCLevel in PCLevelListe:
		PCLevel = raw_input('Falsche Eingabe! Nur Level 1-5! Level:')

	n2 = random.choice(PCNamensliste)
	while n1 == n2:
		n2 = random.choice(PCNamensliste)
	print('PC Name: ' + str(n2))
	i2 = Player()
	i2.s_N(n2)

	i1.s_P(0)
	i2.s_P(0)
	clear()

	while True:

		if PCLevel == '1':
			PCLevelEinfach()

		if PCLevel == '2':
			r= randint(1,2)
			if r == 1:
				PCLevelEinfach()
			if r ==2:
				a1Auswahl()
				a2 = random.choice(liste)
				i2.s_A(a2)
				Spielen()

		if PCLevel == '3':
			a1Auswahl()
			a2 = random.choice(liste)
			i2.s_A(a2)
			Spielen()

		if PCLevel == '4':
			r= randint(1,2)
			if r == 1:
				PCLevelSchwer()
			if r ==2:
				a1Auswahl()
				a2 = random.choice(liste)
				i2.s_A(a2)
				Spielen()

		if PCLevel == '5':
			PCLevelSchwer()
			
			
		Game -= 1
		if Game >= 1:
			ImSpiel()
		if Game == 0:
			EndSpiel()
			if PCLevel == '3':
				f = file('Bestenliste1vPC.data')
				d = p.load(f)
				f.close()

				schongespielt1 = False

				for i in d:
					if i == i1.g_N():
						d[i] += i1.g_P()
						schongespielt1 = True
				if schongespielt1 == False:
					d [str(i1.g_N())] = int(i1.g_P())

				f = file('Bestenliste1vPC.data', 'w')
				p.dump(d, f)
				f.close()
				print(d)

				Best = max_dict(d)
			break
if SM == '3':
	n1 = random.choice(PCNamensliste)
	print('PC Name: ' + str(n1))
	i1 = Player()
	i1.s_N(n1)

	n2 = random.choice(PCNamensliste)
	while n1 == n2:
		n2 = random.choice(PCNamensliste)
	print('PC Name: ' + str(n2))
	i2 = Player()
	i2.s_N(n2)

	i1.s_P(0)
	i2.s_P(0)

	while True:

		a1 = random.choice(liste)
		a2 = random.choice(liste)

		i1.s_A(a1)
		i2.s_A(a2)

		Spielen()

		Game -= 1
		if Game >= 1:
			ImSpiel()
		if Game == 0:
			EndSpiel()

			PCSpieleDatei = 'PCSpieleAnzahl.data'
			f = file(PCSpieleDatei)
			PCSpieleAnzahl = p.load(f)
			f.close()

			PCSpieleAnzahl += 1

			f = file(PCSpieleDatei, 'w')
			p.dump(PCSpieleAnzahl, f)
			f.close()
			Auswertung = str('Spiel Nummer ' + str(PCSpieleAnzahl) + ': ' + str(n1) + ' vs. ' + str(n2) + ' | Punktestand:' + str(i1.g_P()) + ' : ' + str(i2.g_P()) + ' | Anzahl gespielter Runden: ' + str(Gameround))
			f2 = file('PCSpiele.txt', 'a')
			f2.write(Auswertung + '\n')
			f2.close()

			print(Auswertung)
			
			BPCvPC = 'BestenlistePCvPC.data'
			f3 = file(BPCvPC)
			d = p.load(f3)
			f3.close()

			schongespielt1 = False
			schongespielt2 = False
			for i in d:
				if i == i1.g_N():
					d[i] += i1.g_P()
					schongespielt1 = True
				elif i == i2.g_N():
					d[i] += i2.g_P()
					schongespielt2 =True
			if schongespielt1 == False:
				d [str(i1.g_N())] = int(i1.g_P())
			if schongespielt2 == False:
				d [str(i2.g_N())] = int(i2.g_P())
			f3 = file(BPCvPC, 'w')
			p.dump(d, f3)
			f3.close()

			Best = max_dict(d)

			break